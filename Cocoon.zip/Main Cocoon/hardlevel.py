import sys
from PyQt6.QtWidgets import QApplication, QMainWindow
from PyQt6.uic import loadUi
from PyQt6.QtGui import QTextCharFormat, QColor

from db import Database, User
db_url = "mysql+mysqlconnector://cocoon:FlyWithCocoon@localhost/cocoon"
db = Database(db_url)

class HardLevel(QMainWindow):
    def __init__(self, ID):
        super().__init__()
        self.id = ID
        self.setWindowTitle("Hard level")
        loadUi("./ui/newhardlevel.ui", self)
        self.submit.clicked.connect(self.evaluateCode)

    def evaluateCode(self):
        self.output.clear()
        code = self.codeEdit.toPlainText()
        try:
            local_namespace = {}
            exec(code, globals(), local_namespace)
            myFunc = self.getFunctionName(local_namespace)
            if myFunc:
                results = []
                test_cases = [(0, True), (2, True), (5, False), (11, False)]  
                for input_value, expected_output in test_cases:
                    result = myFunc(input_value)
                    results.append((input_value, result))
                
                correctness = self.correctness(results, test_cases)
                db.updateCorrectness(correctness, self.id)
                self.output.append(f"Your code is {correctness}% correct.")
            else:
                self.output.insertPlainText("\nPlease define a function to evaluate")

        except Exception as e:
            self.output.insertPlainText(f"Error: {e}")
            print(e)

    def correctness(self, results, test_cases):
        cases = len(test_cases)
        correct_answer_count = 0
        for i in range(0, cases):
            if results[i] == test_cases[i]:
                correct_answer_count+=1
                self.display_results(results[i], "green")
            else:
                self.display_results(results[i], "red")
                for ip, op in results:
                        self.output.append(f"{ip}: {op}")

        correctness = correct_answer_count * 100 / cases
        return correctness


    def display_results(self, result, color):
        color_format = QTextCharFormat()
        color_format.setForeground(QColor(color))
        self.output.setCurrentCharFormat(color_format)

        input_value, output_value = result
        formatted_output = f"{str(input_value).replace(',', '')}: {str(output_value).replace(',', '')}\n"
        self.output.insertPlainText(formatted_output)

        default_format = QTextCharFormat()
        self.output.setCurrentCharFormat(default_format)
        

    def getFunctionName(self, local_namespace):
        for name, obj in local_namespace.items():
            if callable(obj):
                return obj
        return None


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = HardLevel(2)
    window.show()
    sys.exit(app.exec())
