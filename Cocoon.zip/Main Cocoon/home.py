import sys
from PyQt6.QtWidgets import QApplication, QMainWindow, QStackedWidget
from homepage_ui import Ui_MainWindow
from PyQt6 import QtCore

from codelevel import CodeLevel
from easylevel import EasyLevel

class HomePage(QMainWindow):
    def __init__(self, id, widget):
        super().__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.id = id
        self.widget = widget
        # Connect buttons to their respective functions
        self.ui.pushButton.clicked.connect(self.openCaterpillarPage)
        self.ui.pushButton_2.clicked.connect(self.openChrysalidPage)
        self.ui.pushButton_3.clicked.connect(self.openButterflyPage)

    def openCaterpillarPage(self):
        # Handle opening the caterpillar page
        self.ui.label_3.setText("Caterpillar Page Opened")
        questions = ["What one the following are Built-in data types in Python?", 
                 "What is __init__() in Python?",
                 "Does Python support multiple Inheritance?",
                 "Which of the following is not a valid Python data type?",
                 "What is the correct way to declare a variable in Python?",
                 "How do you denote a block of code in Python?",
                 "Which symbol is used for single line comments in Python?",
                 "Which of the following is not a valid Python data type?",
                 "What will be the output of the following code?\nx = 10\nprint('The value of x is:', x)",
                 "What will be the output of the following code?\nprint(10 > 5)",
                 ]
        
        options = [("Numeric", "Sequence Type", "Mapping Types", "All of the above Types"),
                   ("A reserved keyword in Python", "A method called automatically when a new object is defined.", "A function used for mathematical calculations."),
                   ("Yes", "No", "Sometimes", "None of the above"),
                   ("int", "float", "double", "str"),
                   ("variable x", "var x", "x = 5", "declare x = 5"),
                   ("{}", "[]", "()", "Indentation"),
                   ("//", "#", "--", "/**/"),
                   ("List", "Integer", "Float", "Character"),
                   ("The value of x is: 10", "The value of  is: 'x'","The value of x is: 'x'", "None of the above"),
                   ("True", "False", "Error", "None of the above"),
                    ]
        
        correct_answers = [3, 3, 0, 2, 2, 3, 1, 3, 0, 0]
        caterpillar = EasyLevel(self.id, questions, options, correct_answers)
        self.close()
        self.widget.addWidget(caterpillar)
        self.widget.setCurrentIndex(self.widget.currentIndex()+1)

    def openChrysalidPage(self):
        # Handle opening the chrysalid page
        self.ui.label_3.setText("Chrysalid Page Opened")
        self.widget.setWindowTitle("Intermediate Level")
        questions = ["Write a Python function to calculate the factorial of a given a positive number.", 
                 "Write a Python function to check if a given number is prime.",
                 "Write a Python function that displays last number of Fibonacci series consisting of n terms",
                 "Write a Python function to find the sum of all elements in a list.",
                 "Write a Python function to find the largest element in a list."]
    
        hints = ["Use a loop or recursion to multiply the numbers.", 
                "Try dividing the number by each integer up to its square root to check for factors.",
                "The Fibonacci sequence is a series of numbers where each number is the sum of the two preceding ones. \nE.g 0 1 1 2 3 5...",
                "Use a loop to iterate through each element and add it to a running total.",
                "Initialize a variable with the first element and compare it with each subsequent element."]
        
        tests = [
                [(0, 1), (1, 1), (5, 120), (10, 3628800), (3, 6)], #Factorial
                [(80, False), (19, True), (43, True), (98, False), (47, True)], #Prime
                [(5, 5) ,(8, 21), (10, 55) ,(20, 6765), (15, 610)], #Fibonacci
                [([1, 2, 3, 4, 5], 15), ([10, 20, 30, 40, 50], 150), ([3, 5, 7, 9, 11], 35), ([2, 4, 6, 8, 10], 30), ([15, 25, 35, 45, 55], 175)], #Sum of list
                [([1, 2, 3, 4, 5], 5), ([10, 20, 30, 40, 50], 50), ([-5, -3, -9, -1], -1), ([100, 200, 150, 300], 300), ([0], 0)]
                ]
        chrysalid = CodeLevel(self.id, questions, tests, hints)
        self.close()
        self.widget.addWidget(chrysalid)
        self.widget.setCurrentIndex(self.widget.currentIndex()+1)




    def openButterflyPage(self):
        # Handle opening the butterfly page
        self.widget.setWindowTitle("Intermediate Level")
        questions = ["Write a Python function to implement a stack using a list. Implement method pop() to accept a list of numbers from which one element is popped from the stack.", 
                 "Write a Python function to implement a queue using a list. Implement method enqueue() that accepts a list of numbers and adds it into the queue.",
                 "Write a Python function named linear_search that takes a target element target.\nThe function should return the index of the target element in the list if found, otherwise return -1.",
                 "Write a Python function named is_palindrome that takes a string 's' as input and returns True if 's' is a palindrome, and False otherwise.",
                 "Write a Python function named binary_search that takes a target element target.\nThe function should return the index of the target element in the list if found, otherwise return -1."]
    
        hints = ["You can use the pop methods of lists to implement pop() for a stack.", 
                "For enqueue(), use the append() method to add elements to the end of the list.",
                "Use a loop to iterate through each element in the list and check if it matches the target element. The list is [10, 20, 40, 30, 90, 67, 54]",
                "A string is palindrome if spelled backwards remains the same.",
                "Use the divide-and-conquer approach by comparing the target element with the middle elementof the list. The sorted list is [2, 4, 6, 8, 10, 12, 14]"]
        
        tests = [[([23, 12, 8], [23, 12]), ([1, 2, 4, 5, 6], [1, 2, 4, 5]), ([2], []), ([0, 9], [0]), ([9, 100, 34], [9, 100])],
                [([1, 3, 4], [1, 3, 4]), ([3, 4 ,8], [3, 4, 8]), ([2, 4, 6, 8, 10, 12, 14], [2, 4, 6, 8, 10, 12, 14]), ([10, 20, 30], [10, 20, 30]), ([5, 10, 15, 20], [5, 10, 15, 20])],
                [(30, 3), (1, -1), (67, 5), (100, -1), (20, 1)],
                [("Malayalam", True), ("hello", False), ("racecar", True), ("cocoon", False), ("radar", True)],
                [(90, -1), (8, 3), (10, 4), (169, -1), (14, 7)]]
        butterfly = CodeLevel(self.id, questions, tests, hints)
        self.close()
        self.widget.addWidget(butterfly)
        self.widget.setCurrentIndex(self.widget.currentIndex()+1)
