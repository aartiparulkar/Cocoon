from PyQt6 import QtWidgets, QtCore
from PyQt6.QtWidgets import QMessageBox, QLineEdit
from PyQt6.uic import loadUi
from PyQt6.QtGui import QIcon

import sys
import home

import smtplib
import random

def send_otp(email):
    """my_email = "aarti.parulkar@student.sfit.ac.in"
    password = "rhre zthd uynw pfjv"""

    my_email = "myycocoon@gmail.com"
    password = "cxrn ekqs sizj iwbi"
    otp = ""
    for _ in range(6):
        otp+=str(random.choice(range(10)))
    
    with smtplib.SMTP("smtp.gmail.com", 587) as connection:

        connection.starttls()
        connection.login(user=my_email, password=password)
        connection.sendmail(from_addr=my_email, to_addrs=email, msg=otp)
    return otp


from db import Database, User
db_url = "mysql+mysqlconnector://cocoon:FlyWithCocoon@localhost/cocoon"
db = Database(db_url)


class Login(QtWidgets.QWidget):
    def __init__(self):
        super(Login, self).__init__()
        loadUi("./ui/login.ui", self)
        self.loginBtn.clicked.connect(self.login)
        self.toolButton.clicked.connect(self.openRegister)
        self.eye.setCheckable(True)
        self.eye.toggled.connect(self.toggle_password_visibility)


    def login(self):
        username = self.userEdit.text()
        password = self.passwordEdit.text()
        
        user = db.get_user_by_username(username)
        if user and user.password == password:
            QMessageBox.information(self, "Login Successful", "Logged in successfully!")
            self.close()
            homepage = home.HomePage(db.get_user_id(username), widget)
            homepage.show()
            widget.addWidget(homepage)
            widget.setCurrentIndex(widget.currentIndex()+1)

        else:
            QMessageBox.warning(self, "Password Mismatch", "Passwords don't match. Please enter them again.")


    def openRegister(self):
        register = Register()
        widget.addWidget(register)
        widget.setCurrentIndex(widget.currentIndex()+1)


    def toggle_password_visibility(self, checked):
        if checked:
            self.passwordEdit.setEchoMode(QLineEdit.EchoMode.Normal)
            self.eye.setIcon(QIcon("./myicon/pngs/show.png"))
        else:
            self.passwordEdit.setEchoMode(QLineEdit.EchoMode.Password)
            self.eye.setIcon(QIcon("./myicon/pngs/hide.png"))


class Register(QtWidgets.QWidget):
    def __init__(self):
        super(Register,self).__init__()
        loadUi("./ui/register.ui", self)
        self.signupBtn.clicked.connect(self.register)
        self.jmpLogin.clicked.connect(self.openLogin)
        self.eye.setCheckable(True)
        self.eye.toggled.connect(self.toggle_password_visibility)


    def register(self):
        username = self.userEdit.text()
        password = self.passEdit.text()
        email = self.emailEdit.text()
        
        if User.verify_password(password):
            user_exists = db.get_user_by_username(username)
            email_exists = db.get_user_by_email(email)

            if not user_exists and not email_exists:
                otp = send_otp(email)
                otp_window = OTP(otp, username, password, email)
                widget.addWidget(otp_window)
                widget.setCurrentIndex(widget.currentIndex() + 1)

            elif user_exists:
                QMessageBox.warning(self, "Username Exists", "Username already exists. Please choose a different one.")
            elif email_exists:
                QMessageBox.warning(self, "Email Exists", "Email already exists. Please use a different one.")
        else:
            QMessageBox.warning(self, "Password Requirement", "Password must be at least 8 characters long and contain at least 1 special character and 1 number.")
        

    def add_user(self, username, email, password):
        db.insert_user(username, email, password)
        QMessageBox.information(self, "Registration Successful", "Registered successfully!")     


    def openLogin(self):
        login = Login()
        widget.addWidget(login)
        widget.setCurrentIndex(widget.currentIndex()+1)


    def toggle_password_visibility(self, checked):
        if checked:
            self.passEdit.setEchoMode(QLineEdit.EchoMode.Normal)
            self.eye.setIcon(QIcon("./myicon/pngs/show.png"))
        else:
            self.passEdit.setEchoMode(QLineEdit.EchoMode.Password)
            self.eye.setIcon(QIcon("./myicon/pngs/hide.png"))     


class OTP(QtWidgets.QWidget):
    def __init__(self, otp, username, password, email):
        super(OTP,self).__init__()
        loadUi("./ui/otp.ui", self)
        self.otp = otp
        print(self.otp)
        self.username = username
        self.password = password
        self.email = email
        self.nextBtn.clicked.connect(self.openNextPage)
        self.to_signup.clicked.connect(self.toRegister)


    def openNextPage(self):
        entered_otp = self.otp_edit.text() 
        if entered_otp == self.otp:
            db.insert_user(self.username,self.email, self.password)
            QMessageBox.information(self, "Registration Successful", "Registered Successfully!")
            homepage = home.HomePage(db.get_user_id(self.username), widget)
            homepage.show()
            widget.addWidget(homepage)
            widget.setCurrentIndex(widget.currentIndex()+1)
        else:
            QMessageBox.warning(self, "Invalid OTP", "Invalid OTP. Please try again.")
    

    def toRegister(self):
        register = Register()
        widget.addWidget(register)
        widget.setCurrentIndex(widget.currentIndex()+1)

        

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    mainWindow = Login()
    widget = QtWidgets.QStackedWidget()
    widget.addWidget(mainWindow)


    #widget.setWindowFlags(QtCore.Qt.WindowType.FramelessWindowHint)
    #widget.setAttribute(QtCore.Qt.WidgetAttribute.WA_TranslucentBackground)
    widget.setGeometry(QtCore.QRect(500, 200, 750, 590))
    widget.setFixedSize(750, 590)
    widget.show()
    sys.exit(app.exec())