from PyQt6.QtWidgets import QStackedWidget, QMessageBox, QMainWindow
from PyQt6.uic import loadUi

from db import Database
db_url = "mysql+mysqlconnector://cocoon:FlyWithCocoon@localhost/cocoon"
db = Database(db_url)


class EasyLevel(QMainWindow):

    def __init__(self, id, questions, options, correct_answers):
        super().__init__()
        loadUi("./ui/easy.ui", self)
        self.current_question_index = 0
        self.questions_list = list()
        self.id = id
        print("ID: ", self.id)
        self.questions = questions
        self.options = options
        self.answers = correct_answers
        self.score = 0
        self.question_count_label = self.ques_count_label
        self.question_text = self.ques_edit
        self.check_answer_btn = self.check_btn
        self.next_question_btn = self.next_btn
        self.radioButtons = [self.option1, self.option2, self.option3, self.option4]
        self.answer_frame = self.ansFrame
        self.widget = QStackedWidget()
        self.next_question()
        self.check_answer_btn.clicked.connect(self.check_answer)
        self.next_question_btn.clicked.connect(self.next_question)
        self.back_btn.clicked.connect(self.toHome)


    def check_answer(self):
        checked_button = None
        correct_option_index = self.answers[self.current_question_index]
        for button in self.radioButtons:
            if button.isChecked():
                checked_button = button
                break
        if checked_button is not None:
            selected_option_index = self.radioButtons.index(checked_button)
            if selected_option_index == correct_option_index:
                # Correct answer
                checked_button.setStyleSheet("QRadioButton { background-color: green; color: white;}")
                self.score+=1
            else:
                # Incorrect answer
                checked_button.setStyleSheet("QRadioButton { background-color: red; color: white;}")
            for button in self.radioButtons:
                button.setEnabled(False)
            self.next_btn.setEnabled(True)
            self.current_question_index += 1

        else:
            # No radio button checked
            QMessageBox.warning(self, "Empty Input", "Please select an option") 

    def updateCorrectness(self):
         self.correctness = self.score * 10
         db.updateCorrectness(correctness=self.correctness, ID=self.id)

    def next_question(self):
        for button in self.radioButtons:
                button.setStyleSheet("")
                button.setEnabled(True)
        self.ques_edit.clear()
        ques_count_label = self.current_question_index+1
        self.question_count_label.setText(f"{ques_count_label}/10")
        if self.current_question_index < len(self.questions):
            # Set question text
            self.ques_edit.appendPlainText(self.questions[self.current_question_index])
            
            for radiobutton, option in zip(self.radioButtons, self.options[self.current_question_index]):
                #for button, option in zip(self.radioButtons, options):
                    radiobutton.setText(option)
            # Set correct answer
            self.correct_answer = self.answers[self.current_question_index]
        else:
            # Display a message or handle end of questions
            QMessageBox.information(self, "Level Completion", f"Final Score: {self.score}/10")
            self.updateCorrectness()
        

    def toHome(self):
        from home import HomePage
        widget = QStackedWidget(self) 
        home_page = HomePage(self.id, widget)  
        widget.addWidget(home_page)
        widget.setCurrentIndex(widget.currentIndex() + 1)
        self.setCentralWidget(widget)