import os
import sys
from PyQt6.QtWidgets import QMainWindow, QApplication, QLabel, QListWidgetItem, QWidget, QGridLayout
from PyQt6.QtCore import Qt, QSize
from PyQt6.QtGui import QIcon, QPixmap, QFont


# Import the UI class from the 'menu_ui' module
from sidebar_ui import Ui_MainWindow


# Define a custom MainWindow class
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        # Initialize the UI from the generated 'menu_ui' class
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)

        # Initialize UI elements 
        self.title_label = self.ui.title_label
        self.title_label.setText("Cocoon")

        self.title_icon = self.ui.title_icon
        self.title_icon.setText("")
        self.title_icon.setPixmap(QPixmap("./myicon/svg/logo.svg"))
        self.title_icon.setScaledContents(True)

        self.side_menu = self.ui.listWidget
        self.side_menu.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.side_menu_icon_only = self.ui.listWidget_icon_only
        self.side_menu_icon_only.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.side_menu_icon_only.setVisible(False)

        self.menu_btn = self.ui.pushButton
        self.menu_btn.setObjectName("menu_btn")
        self.menu_btn.setText("")
        self.menu_btn.setIcon(QIcon("./myicon/pngs/menu.png"))
        self.menu_btn.setIconSize(QSize(16, 16))
        self.menu_btn.setCheckable(True)

        self.main_content = self.ui.stackedWidget

        # Define a list if menu items with names and icons 
        self.menu_list = [
            {
                "name": "Home",
                "icon": "./myicon/svg/home.svg"
            },
            {
                "name": "Dashboard",
                "icon": "./myicon/svg/trophy.svg"
            },
            {
                "name": "Easy",
                "icon": "./myicon/svg/caterpillar.svg"
            },
            {
                "name": "Medium",
                "icon": "./myicon/svg/chrysalid.svg"
            },
            {
                "name": "Hard",
                "icon": "./myicon/svg/butterfly.svg"
            },
        ]

        # Initalize the UI elements and slots
        self.init_list_widget()
        self.init_signal_slot()
        self.init_stackwidget()

    def init_signal_slot(self):
        # Connect signals and slots for menu button and side menu
        self.menu_btn.toggled["bool"].connect(self.side_menu.setHidden)
        self.menu_btn.toggled["bool"].connect(self.title_label.setHidden)
        self.menu_btn.toggled["bool"].connect(self.title_icon.setHidden)
        self.menu_btn.toggled["bool"].connect(self.side_menu_icon_only.setVisible)

        # Connect signals and slots for switching between menu items
        self.side_menu.currentRowChanged["int"].connect(self.main_content.setCurrentIndex)
        self.side_menu_icon_only.currentRowChanged["int"].connect(self.main_content.setCurrentIndex)
        self.side_menu.currentRowChanged['int'].connect(self.side_menu_icon_only.setCurrentRow)
        self.side_menu_icon_only.currentRowChanged['int'].connect(self.side_menu.setCurrentRow)

        self.menu_btn.toggled.connect(self.button_icon_change)

    def button_icon_change(self, status):
        # Change the menu button icon based on its status
        if status:
            self.menu_btn.setIcon(QIcon("./myicon/svg/menu.svg"))
        else:
            self.menu_btn.setIcon(QIcon("./myicon/svg/menu.svg"))

    def init_list_widget(self):
        # Initailize the side menu and side menu with icons only
        self.side_menu.clear()
        self.side_menu_icon_only.clear()

        for menu in self.menu_list:
            # Set items for the side menu with icons only
            item = QListWidgetItem()
            item.setIcon(QIcon(menu.get("icon")))
            item.setSizeHint(QSize(64, 64))
            self.side_menu_icon_only.addItem(item)
            self.side_menu_icon_only.setCurrentRow(0)

            # Set items for the side menu with icons and text
            item_new = QListWidgetItem()
            item_new.setIcon(QIcon(menu.get("icon")))
            item_new.setText(menu.get("name"))
            self.side_menu.addItem(item_new)
            self.side_menu.setCurrentRow(0)

        

    def init_stackwidget(self):
        # Initalize the stack widget with content page
        widget_list = self.main_content.findChildren(QWidget)
        for widget in widget_list:
            self.main_content.removeWidget(widget)

        for menu in self.menu_list:
            text = menu.get("name")
            layout = QGridLayout()
            label = QLabel(text=text)
            label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            font = QFont()
            font.setPixelSize(24)
            label.setFont(font)
            layout.addWidget(label)
            new_page = QWidget()
            new_page.setLayout(layout)
            self.main_content.addWidget(new_page)


if __name__ == "__main__":
    app = QApplication(sys.argv)

    #Load style file
    # with open("style.qss") as f:style_str = f.read()

    # app.setStyleSheet(style_str)
    
    # Load style file using absolute path
    style_file_path = os.path.abspath("./ui/style.qss")
    if os.path.exists(style_file_path):
        with open(style_file_path) as f:
            style_str = f.read()
        app.setStyleSheet(style_str)
    else:
        print("Style file not found:", style_file_path)
        # You can add further error handling here if needed

    window = MainWindow()
    window.show()

    sys.exit(app.exec())