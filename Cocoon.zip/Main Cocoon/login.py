from PyQt6 import QtWidgets, QtCore
from PyQt6.QtGui import QIcon
from PyQt6.uic import loadUi
from PyQt6.QtWidgets import QMessageBox, QLineEdit
from register import Register
import sys

from db import Database, User
db_url = "mysql+mysqlconnector://cocoon:FlyWithCocoon@localhost/cocoon"
database = Database(db_url)

class Login(QtWidgets.QWidget):
    def __init__(self):
        super(Login, self).__init__()
        loadUi("./ui/login.ui", self)
        self.loginBtn.clicked.connect(self.login)
        self.toolButton.clicked.connect(self.openRegister)
        self.eye.setCheckable(True)
        self.eye.toggled.connect(self.toggle_password_visibility)


    def login(self):
        username = self.userEdit.text()
        password = self.passwordEdit.text()
        
        user = database.get_user_by_username(username)
        if user and user.password == password:
            QMessageBox.information(self, "Login Successful", "Logged in successfully!")

        else:
            QMessageBox.warning(self, "Password Mismatch", "Passwords don't match. Please enter them again.")


    def openRegister(self):
        register = Register()
        widget.addWidget(register)
        widget.setCurrentIndex(widget.currentIndex()+1)


    def toggle_password_visibility(self, checked):
        if checked:
            self.passwordEdit.setEchoMode(QLineEdit.EchoMode.Normal)
            self.eye.setIcon(QIcon("./myicon/pngs/show.png"))
        else:
            self.passwordEdit.setEchoMode(QLineEdit.EchoMode.Password)
            self.eye.setIcon(QIcon("./myicon/pngs/hide.png"))

if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    mainWindow = Login()
    widget = QtWidgets.QStackedWidget()
    widget.addWidget(mainWindow)

    widget.setWindowFlags(QtCore.Qt.WindowType.FramelessWindowHint)
    widget.setAttribute(QtCore.Qt.WidgetAttribute.WA_TranslucentBackground)
    widget.setGeometry(QtCore.QRect(50, 50, 590, 420))
    widget.show()
    sys.exit(app.exec())
