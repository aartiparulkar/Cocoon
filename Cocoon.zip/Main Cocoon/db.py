from sqlalchemy import create_engine, Column, Integer, String, Float
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import sessionmaker
import re

Base = declarative_base()

class User(Base):
    __tablename__ = 'users'

    id = Column(Integer, primary_key=True)
    username = Column(String(100), unique=True)
    email = Column(String(100), unique=True)
    password = Column(String(100))
    correctness = Column(Float, default=0.0)


    def __repr__(self):
        return f"<User(username='{self.username}', email='{self.email}', password='{self.password}', correctness='{self.correctness}')>"
    

    def verify_password(password):
        # Minimum 8 characters, at least one letter, one number and one special character
        pattern = r"^(?=.*[A-Za-z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$"
        return bool(re.match(pattern, password))


class Database:
    def __init__(self, db_url):
        self.engine = create_engine(db_url)
        Base.metadata.create_all(self.engine)
        Session = sessionmaker(bind=self.engine)
        self.session = Session()


    def insert_user(self, username, email, password):
        new_user = User(username=username, email=email, password=password)
        self.session.add(new_user)
        self.session.commit()

    def updateCorrectness(self, correctness, ID):
        user = self.session.query(User).filter_by(id=ID).first()
        if user:
            if user.correctness is not None:
                updated_correctness = (correctness + user.correctness) / 2
            else:
                updated_correctness = correctness
            user.correctness = updated_correctness
            self.session.commit()

    def get_user_by_username(self, username):
        return self.session.query(User).filter_by(username=username).first()
    

    def get_user_by_email(self, email):
        return self.session.query(User).filter_by(email=email).first()
    
    def get_user_id(self, username):
        user = self.session.query(User).filter_by(username=username).first()
        if user:
            return user.id
        else:
            return None


