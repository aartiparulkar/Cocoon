from PyQt6 import QtWidgets, QtCore
from PyQt6.QtGui import QIcon
from PyQt6.uic import loadUi
import db
from PyQt6.QtWidgets import QMessageBox, QLineEdit

import smtplib
import random

class Register(QtWidgets.QWidget):
    def __init__(self):
        super(Register,self).__init__()
        loadUi("./ui/register.ui", self)
        self.signupBtn.clicked.connect(self.verify)
        self.jmpLogin.clicked.connect(self.openLogin)
        self.eye.setCheckable(True)
        self.eye.toggled.connect(self.toggle_password_visibility)


    def register(self):
        username = self.userEdit.text()
        password = self.passEdit.text()
        email = self.emailEdit.text()
        
        self.get_otp_btn.clicked.connect(self.verify)

        if db.User.verify_password(password):
            user_exists = db.get_user_by_username(username)
            email_exists = db.get_user_by_email(email)

            if not user_exists and not email_exists:
                db.insert_user(username, email, password)                
            elif user_exists:
                QMessageBox.warning(self, "Username Exists", "Username already exists. Please choose a different one.")
            elif email_exists:
                QMessageBox.warning(self, "Email Exists", "Email already exists. Please use a different one.")
        else:
            QMessageBox.warning(self, "Password Requirement", "Password must be at least 8 characters long and contain at least 1 special character and 1 number.")


    def verify(self):
        email = self.emailEdit.text()
        correct_otp = self.send_otp(email)

        user_otp = self.otp_edit.text()
        if correct_otp == user_otp:
            QMessageBox.information(self, "Registration Successful", "Registered successful!.")
        else:
            QMessageBox.warning(self, "Invalid Information", "Invalid OTP. Please enter again.")
        

    def add_user(self, username, email, password):
        db.insert_user(username, email, password)
        QMessageBox.information(self, "Registration Successful", "Registered successfully!")

    def openLogin(self):
        from login import Login
        login = Login()


    def toggle_password_visibility(self, checked, eye):
        if checked:
            self.passEdit.setEchoMode(QLineEdit.EchoMode.Normal)
            self.eye.setIcon(QIcon("./myicon/pngs/show.png"))
        else:
            self.passEdit.setEchoMode(QLineEdit.EchoMode.Password)
            self.eye.setIcon(QIcon("./myicon/pngs/hide.png"))     


    def send_otp(email):
        my_email = "aarti.parulkar@student.sfit.ac.in"
        password = "rhre zthd uynw pfjv"
        otp = ""
        for _ in range(6):
            otp+=str(random.choice(range(10)))
        
        with smtplib.SMTP("smtp.gmail.com") as connection:
            connection.starttls()
            print(my_email, password)
            connection.login(my_email, password)
            connection.sendmail(from_addr=my_email, to_addrs=email, msg=f"Subject:OTP for  Registration\n\nOTP: {otp}")
        return otp

